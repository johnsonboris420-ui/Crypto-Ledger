// ============================================================
//  Mandelbulb 4D — GPU ray-marched via GLSL fragment shader
//  Renders 3D slices through a 4D Mandelbulb fractal
// ============================================================

// --- Shader sources ---

const VS = `#version 300 es
in vec2 a_pos;
out vec2 v_uv;
void main(){
  v_uv = a_pos * 0.5 + 0.5;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}`;

const FS = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform float u_time;
uniform vec2 u_resolution;
uniform float u_power;
uniform float u_wSlice;
uniform float u_iterations;
uniform float u_colorShift;
uniform float u_glow;
uniform float u_fog;
uniform vec3 u_camPos;
uniform mat3 u_camMat;

const int MAX_STEPS = 200;
const float MAX_DIST = 12.0;
const float SURF_DIST = 0.0005;
const float PI = 3.14159265;

// 4D Mandelbulb distance estimator
// Takes a 3D point + w-slice to form the 4D coordinate
vec2 mandelbulb4D(vec3 pos, float w, float power, int iters) {
  vec4 z = vec4(0.0);
  vec4 c = vec4(pos, w);
  float dr = 1.0;
  float r = 0.0;
  float trap = 1e10;

  for (int i = 0; i < 24; i++) {
    if (i >= iters) break;

    r = length(z);
    if (r > 4.0) break;

    // Track orbit trap for coloring
    trap = min(trap, length(z.xyz));

    // Derivative for distance estimation
    dr = pow(r, power - 1.0) * power * dr + 1.0;

    // Hyperspherical coordinates in 4D
    float r_xy = length(z.xy);
    float r_xyz = length(z.xyz);

    float phi = atan(z.y, z.x);
    float theta = (r_xy > 0.0001) ? atan(z.z, r_xy) : 0.0;
    float psi = (r_xyz > 0.0001) ? atan(z.w, r_xyz) : 0.0;

    float r_new = pow(r, power);
    float phi_n = power * phi;
    float theta_n = power * theta;
    float psi_n = power * psi;

    float cp = cos(phi_n);
    float sp = sin(phi_n);
    float ct = cos(theta_n);
    float st = sin(theta_n);
    float cps = cos(psi_n);
    float sps = sin(psi_n);

    z = r_new * vec4(
      sps * ct * cp,
      sps * ct * sp,
      sps * st,
      cps
    ) + c;
  }

  // DE = 0.5 * r * log(r) / dr
  float dist = 0.5 * log(max(r, 1e-10)) * r / dr;
  return vec2(dist, trap);
}

// Normal via central differences
vec3 getNormal(vec3 p, float w, float power, int iters) {
  float h = 0.0005;
  vec2 k = vec2(1, -1);
  return normalize(
    k.xyy * mandelbulb4D(p + k.xyy * h, w, power, iters).x +
    k.yyx * mandelbulb4D(p + k.yyx * h, w, power, iters).x +
    k.yxy * mandelbulb4D(p + k.yxy * h, w, power, iters).x +
    k.xxx * mandelbulb4D(p + k.xxx * h, w, power, iters).x
  );
}

// Soft shadow
float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k, float w, float power, int iters) {
  float res = 1.0;
  float t = mint;
  for (int i = 0; i < 48; i++) {
    float h = mandelbulb4D(ro + rd * t, w, power, iters).x;
    res = min(res, k * h / t);
    t += clamp(h, 0.002, 0.1);
    if (res < 0.001 || t > maxt) break;
  }
  return clamp(res, 0.0, 1.0);
}

// Ambient occlusion
float ao(vec3 p, vec3 n, float w, float power, int iters) {
  float occ = 0.0;
  float scale = 1.0;
  for (int i = 0; i < 5; i++) {
    float h = 0.01 + 0.06 * float(i);
    float d = mandelbulb4D(p + n * h, w, power, iters).x;
    occ += (h - d) * scale;
    scale *= 0.6;
  }
  return clamp(1.0 - 3.0 * occ, 0.0, 1.0);
}

// Palette function (iq)
vec3 palette(float t, float shift) {
  t = t + shift;
  vec3 a = vec3(0.5, 0.5, 0.5);
  vec3 b = vec3(0.5, 0.5, 0.5);
  vec3 c = vec3(1.0, 1.0, 1.0);
  vec3 d = vec3(0.10, 0.20, 0.35);
  return a + b * cos(6.28318 * (c * t + d));
}

void main() {
  vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution) / u_resolution.y;
  int iters = int(u_iterations);

  // Ray direction
  vec3 rd = normalize(u_camMat * vec3(uv, 1.2));
  vec3 ro = u_camPos;

  // March
  float t = 0.0;
  float trap = 0.0;
  float glow_acc = 0.0;
  bool hit = false;

  for (int i = 0; i < MAX_STEPS; i++) {
    vec3 p = ro + rd * t;
    vec2 d = mandelbulb4D(p, u_wSlice, u_power, iters);
    float dist = d.x;

    glow_acc += exp(-dist * 20.0) * 0.004;

    if (dist < SURF_DIST) {
      trap = d.y;
      hit = true;
      break;
    }
    t += dist * 0.7; // step conservatively
    if (t > MAX_DIST) break;
  }

  vec3 col;

  if (hit) {
    vec3 p = ro + rd * t;
    vec3 n = getNormal(p, u_wSlice, u_power, iters);

    // Lighting
    vec3 light1 = normalize(vec3(0.7, 1.0, 0.5));
    vec3 light2 = normalize(vec3(-0.5, 0.3, -0.7));

    float diff1 = max(dot(n, light1), 0.0);
    float diff2 = max(dot(n, light2), 0.0);

    // Specular (Blinn-Phong)
    vec3 h1 = normalize(light1 - rd);
    float spec1 = pow(max(dot(n, h1), 0.0), 64.0);

    // Shadow & AO
    float sh = softShadow(p + n * 0.002, light1, 0.01, 3.0, 12.0, u_wSlice, u_power, iters);
    float occ = ao(p, n, u_wSlice, u_power, iters);

    // Material color from orbit trap + palette
    vec3 matCol = palette(trap * 1.5, u_colorShift);

    // Compose lighting
    vec3 ambient = vec3(0.05, 0.04, 0.08);
    col = matCol * (
      ambient * occ +
      diff1 * vec3(1.0, 0.95, 0.9) * sh * occ +
      diff2 * vec3(0.2, 0.25, 0.4) * occ * 0.5
    );
    col += spec1 * vec3(1.0, 0.95, 0.85) * sh * 0.6;

    // Fresnel rim
    float fresnel = pow(1.0 - max(dot(n, -rd), 0.0), 3.0);
    col += fresnel * vec3(0.3, 0.2, 0.5) * 0.3;

    // Distance fog
    float fogAmt = 1.0 - exp(-u_fog * t * t);
    col = mix(col, vec3(0.02, 0.015, 0.03), fogAmt);

  } else {
    // Background gradient
    float grad = uv.y * 0.3 + 0.5;
    col = mix(vec3(0.02, 0.015, 0.03), vec3(0.04, 0.03, 0.06), grad);
  }

  // Glow overlay
  vec3 glowCol = palette(glow_acc * 3.0 + u_time * 0.05, u_colorShift);
  col += glowCol * glow_acc * u_glow;

  // Tone mapping (ACES approx)
  col = col / (col + 0.5);

  // Vignette
  vec2 q = v_uv;
  col *= 0.6 + 0.4 * pow(16.0 * q.x * q.y * (1.0 - q.x) * (1.0 - q.y), 0.2);

  // Gamma
  col = pow(col, vec3(0.4545));

  fragColor = vec4(col, 1.0);
}`;

// --- WebGL setup ---

const canvas = document.getElementById('gl');
const gl = canvas.getContext('webgl2', { antialias: false, powerPreference: 'high-performance' });

if (!gl) {
  document.body.innerHTML = '<div style="display:grid;place-items:center;height:100vh;color:#888;font-family:monospace;">WebGL 2 not supported</div>';
  throw new Error('No WebGL2');
}

function compileShader(src, type) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(s));
    throw new Error('Shader compile error');
  }
  return s;
}

const prog = gl.createProgram();
gl.attachShader(prog, compileShader(VS, gl.VERTEX_SHADER));
gl.attachShader(prog, compileShader(FS, gl.FRAGMENT_SHADER));
gl.linkProgram(prog);
if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
  throw new Error(gl.getProgramInfoLog(prog));
}
gl.useProgram(prog);

// Fullscreen quad
const buf = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buf);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), gl.STATIC_DRAW);
const aPos = gl.getAttribLocation(prog, 'a_pos');
gl.enableVertexAttribArray(aPos);
gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

// Uniforms
const loc = {};
['u_time','u_resolution','u_power','u_wSlice','u_iterations',
 'u_colorShift','u_glow','u_fog','u_camPos','u_camMat'].forEach(n => {
  loc[n] = gl.getUniformLocation(prog, n);
});

// --- State ---
const state = {
  power: 8, wSlice: 0, iterations: 12, colorShift: 0, glow: 0.4, fog: 0.08,
  autoRotate: true, wAnimate: true,
  // Non-stop animated modes
  colorDrift: true,   // slowly rotate the color palette
  powerMorph: true,   // gently oscillate power
  breathe: true,      // subtle zoom breathing
  // Camera (spherical)
  theta: 0.3, phi: 0.0, radius: 3.0,
  target: [0, 0, 0],
  panX: 0, panY: 0,
  basePower: 8,       // center of power oscillation
  baseRadius: 3.0,    // center of zoom breathing
};

// --- Resize ---
let dpr = Math.min(window.devicePixelRatio, 2);
let renderScale = 1.0; // adaptive

function resize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  const rw = Math.floor(w * dpr * renderScale);
  const rh = Math.floor(h * dpr * renderScale);
  canvas.width = rw;
  canvas.height = rh;
  gl.viewport(0, 0, rw, rh);
  document.getElementById('res').textContent = rw + '×' + rh;
}
window.addEventListener('resize', resize);
resize();

// --- Camera math ---
function getCamPos() {
  const st = Math.sin(state.theta), ct = Math.cos(state.theta);
  const sp = Math.sin(state.phi), cp = Math.cos(state.phi);
  return [
    state.target[0] + state.radius * ct * sp,
    state.target[1] + state.radius * st,
    state.target[2] + state.radius * ct * cp
  ];
}

function getCamMatrix(pos) {
  const t = state.target;
  const fwd = [t[0]-pos[0], t[1]-pos[1], t[2]-pos[2]];
  const len = Math.sqrt(fwd[0]*fwd[0]+fwd[1]*fwd[1]+fwd[2]*fwd[2]);
  fwd[0]/=len; fwd[1]/=len; fwd[2]/=len;
  const up = [0,1,0];
  const right = [
    fwd[1]*up[2]-fwd[2]*up[1],
    fwd[2]*up[0]-fwd[0]*up[2],
    fwd[0]*up[1]-fwd[1]*up[0]
  ];
  const rl = Math.sqrt(right[0]*right[0]+right[1]*right[1]+right[2]*right[2]);
  right[0]/=rl; right[1]/=rl; right[2]/=rl;
  const up2 = [
    right[1]*fwd[2]-right[2]*fwd[1],
    right[2]*fwd[0]-right[0]*fwd[2],
    right[0]*fwd[1]-right[1]*fwd[0]
  ];
  // Column-major for WebGL
  return new Float32Array([
    right[0], right[1], right[2],
    up2[0], up2[1], up2[2],
    fwd[0], fwd[1], fwd[2]
  ]);
}

// --- Input ---
let dragging = false;
let shiftDrag = false;
let lastMouse = [0, 0];

canvas.addEventListener('mousedown', e => {
  dragging = true;
  shiftDrag = e.shiftKey;
  lastMouse = [e.clientX, e.clientY];
  e.preventDefault();
});
window.addEventListener('mouseup', () => { dragging = false; });
window.addEventListener('mousemove', e => {
  if (!dragging) return;
  const dx = e.clientX - lastMouse[0];
  const dy = e.clientY - lastMouse[1];
  lastMouse = [e.clientX, e.clientY];
  if (shiftDrag) {
    // Pan
    state.target[0] -= dx * 0.003;
    state.target[1] += dy * 0.003;
  } else {
    state.phi -= dx * 0.005;
    state.theta += dy * 0.005;
    state.theta = Math.max(-1.5, Math.min(1.5, state.theta));
  }
});
canvas.addEventListener('wheel', e => {
  state.radius *= 1 + e.deltaY * 0.001;
  state.radius = Math.max(0.5, Math.min(10, state.radius));
  e.preventDefault();
}, { passive: false });

// Touch support
let touches = [];
canvas.addEventListener('touchstart', e => {
  touches = Array.from(e.touches);
  e.preventDefault();
}, { passive: false });
canvas.addEventListener('touchmove', e => {
  const newTouches = Array.from(e.touches);
  if (newTouches.length === 1 && touches.length === 1) {
    const dx = newTouches[0].clientX - touches[0].clientX;
    const dy = newTouches[0].clientY - touches[0].clientY;
    state.phi -= dx * 0.005;
    state.theta += dy * 0.005;
    state.theta = Math.max(-1.5, Math.min(1.5, state.theta));
  } else if (newTouches.length === 2 && touches.length === 2) {
    const d1 = Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
    const d2 = Math.hypot(newTouches[0].clientX - newTouches[1].clientX, newTouches[0].clientY - newTouches[1].clientY);
    state.radius *= d1 / d2;
    state.radius = Math.max(0.5, Math.min(10, state.radius));
  }
  touches = newTouches;
  e.preventDefault();
}, { passive: false });

// --- Controls ---
const els = {
  power: document.getElementById('power'),
  wslice: document.getElementById('wslice'),
  iterations: document.getElementById('iterations'),
  colorshift: document.getElementById('colorshift'),
  glow: document.getElementById('glow'),
  fog: document.getElementById('fog'),
};

function syncUI() {
  els.power.value = state.power;
  els.wslice.value = state.wSlice;
  els.iterations.value = state.iterations;
  els.colorshift.value = state.colorShift;
  els.glow.value = state.glow;
  els.fog.value = state.fog;
  document.getElementById('val-power').textContent = state.power.toFixed(1);
  document.getElementById('val-w').textContent = state.wSlice.toFixed(2);
  document.getElementById('val-iter').textContent = Math.round(state.iterations);
  document.getElementById('val-color').textContent = state.colorShift.toFixed(2);
  document.getElementById('val-glow').textContent = state.glow.toFixed(2);
  document.getElementById('val-fog').textContent = state.fog.toFixed(2);
}

els.power.addEventListener('input', e => { state.power = +e.target.value; syncUI(); });
els.wslice.addEventListener('input', e => { state.wSlice = +e.target.value; syncUI(); });
els.iterations.addEventListener('input', e => { state.iterations = +e.target.value; syncUI(); });
els.colorshift.addEventListener('input', e => { state.colorShift = +e.target.value; syncUI(); });
els.glow.addEventListener('input', e => { state.glow = +e.target.value; syncUI(); });
els.fog.addEventListener('input', e => { state.fog = +e.target.value; syncUI(); });

// Toggle controls panel
const toggleBtn = document.getElementById('toggle-controls');
const controlsInner = document.getElementById('controls-inner');
toggleBtn.addEventListener('click', () => {
  controlsInner.classList.toggle('hidden');
  toggleBtn.classList.toggle('open');
});

// Auto rotate toggle
const rotBtn = document.getElementById('auto-rotate');
rotBtn.addEventListener('click', () => {
  state.autoRotate = !state.autoRotate;
  rotBtn.classList.toggle('active', state.autoRotate);
  rotBtn.textContent = state.autoRotate ? 'ON' : 'OFF';
  rotBtn.setAttribute('aria-pressed', state.autoRotate);
});

// W animate toggle
const wBtn = document.getElementById('w-animate');
wBtn.addEventListener('click', () => {
  state.wAnimate = !state.wAnimate;
  wBtn.classList.toggle('active', state.wAnimate);
  wBtn.textContent = state.wAnimate ? 'ON' : 'OFF';
  wBtn.setAttribute('aria-pressed', state.wAnimate);
});

// Presets
document.querySelectorAll('.preset').forEach(btn => {
  btn.addEventListener('click', () => {
    state.power = parseFloat(btn.dataset.p);
    state.wSlice = parseFloat(btn.dataset.w);
    syncUI();
  });
});

// Start with panel collapsed for cinematic mode
controlsInner.classList.add('hidden');
toggleBtn.classList.remove('open');

// Hint fade
setTimeout(() => {
  const hint = document.getElementById('hint');
  if (hint) hint.classList.add('fade');
}, 4000);

// Sync toggles to reflect non-stop state
wBtn.classList.add('active');
wBtn.textContent = 'ON';
wBtn.setAttribute('aria-pressed', 'true');

syncUI();

// --- Render loop ---
let frameCount = 0;
let fpsTime = performance.now();
const fpsEl = document.getElementById('fps');

function render(time) {
  requestAnimationFrame(render);
  const t = time * 0.001;

  // Adaptive resolution
  frameCount++;
  const now = performance.now();
  if (now - fpsTime > 500) {
    const fps = frameCount / ((now - fpsTime) / 1000);
    fpsEl.textContent = Math.round(fps) + ' fps';
    // Scale down if struggling
    if (fps < 20 && renderScale > 0.4) {
      renderScale = Math.max(0.4, renderScale - 0.05);
      resize();
    } else if (fps > 50 && renderScale < 1.0) {
      renderScale = Math.min(1.0, renderScale + 0.02);
      resize();
    }
    frameCount = 0;
    fpsTime = now;
  }

  // === NON-STOP ANIMATIONS ===

  // Auto orbit — slow, smooth rotation with gentle elevation drift
  if (state.autoRotate) {
    state.phi += 0.002;
    state.theta = 0.3 + Math.sin(t * 0.13) * 0.25; // gentle nod
  }

  // W-slice sweep — breathe through the 4th dimension
  if (state.wAnimate) {
    state.wSlice = Math.sin(t * 0.2) * 0.7 + Math.sin(t * 0.09) * 0.2;
    els.wslice.value = state.wSlice;
    document.getElementById('val-w').textContent = state.wSlice.toFixed(2);
  }

  // Color palette drift
  if (state.colorDrift) {
    state.colorShift = (t * 0.08) % 6.2832;
    els.colorshift.value = state.colorShift;
    document.getElementById('val-color').textContent = state.colorShift.toFixed(2);
  }

  // Power morph — gentle oscillation that keeps the fractal always visible
  if (state.powerMorph) {
    state.power = state.basePower + Math.sin(t * 0.05) * 1.2;
    state.power = Math.max(5, Math.min(12, state.power));
    els.power.value = state.power;
    document.getElementById('val-power').textContent = state.power.toFixed(1);
  }

  // Zoom breathing
  if (state.breathe) {
    state.radius = state.baseRadius + Math.sin(t * 0.15) * 0.3;
  }

  const camPos = getCamPos();
  const camMat = getCamMatrix(camPos);

  gl.uniform1f(loc.u_time, t);
  gl.uniform2f(loc.u_resolution, canvas.width, canvas.height);
  gl.uniform1f(loc.u_power, state.power);
  gl.uniform1f(loc.u_wSlice, state.wSlice);
  gl.uniform1f(loc.u_iterations, state.iterations);
  gl.uniform1f(loc.u_colorShift, state.colorShift);
  gl.uniform1f(loc.u_glow, state.glow);
  gl.uniform1f(loc.u_fog, state.fog);
  gl.uniform3f(loc.u_camPos, camPos[0], camPos[1], camPos[2]);
  gl.uniformMatrix3fv(loc.u_camMat, false, camMat);

  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
}

requestAnimationFrame(render);
